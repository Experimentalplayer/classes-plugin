package org.AlexGems.sPG;

import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.Listener;
import org.bukkit.event.EventHandler;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.ChatColor;

import java.util.HashMap;
import java.util.UUID;

public class Necromancer implements Listener {
    private final HashMap<UUID, Long> wolfCooldown = new HashMap<>();
    private final HashMap<UUID, Long> transformCooldown = new HashMap<>();
    private final HashMap<UUID, Long> soulHarvestCooldown = new HashMap<>();
    private final HashMap<UUID, Boolean> hasClass = new HashMap<>();
    private final SPG plugin;
    private static final int WOLF_COOLDOWN_SECONDS = 30;
    private static final int TRANSFORM_COOLDOWN_SECONDS = 60;
    private static final int SOUL_HARVEST_COOLDOWN_SECONDS = 45;

    public Necromancer(SPG plugin) {
        this.plugin = plugin;
    }

    public HashMap<UUID, Boolean> getHasClassMap() {
        return hasClass;
    }

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        UUID playerId = player.getUniqueId();
        Action action = event.getAction();

        if (!hasClass.getOrDefault(playerId, false)) {
            return;
        }

        if (player.isSneaking() && (action == Action.RIGHT_CLICK_AIR || action == Action.RIGHT_CLICK_BLOCK)) {
            if (isCooldownOver(playerId, wolfCooldown, WOLF_COOLDOWN_SECONDS)) {
                summonWolves(player);
                wolfCooldown.put(playerId, System.currentTimeMillis());
                player.sendMessage(ChatColor.GREEN + "You have summoned three loyal wolves!");
            } else {
                player.sendMessage(ChatColor.RED + "Wolf summon ability is on cooldown!");
            }
            return;
        }

        if (player.isSneaking() && (action == Action.LEFT_CLICK_AIR || action == Action.LEFT_CLICK_BLOCK)) {
            if (isCooldownOver(playerId, transformCooldown, TRANSFORM_COOLDOWN_SECONDS)) {
                transformIntoSkeleton(player);
                transformCooldown.put(playerId, System.currentTimeMillis());
                player.sendMessage(ChatColor.BLUE + "You have transformed into a skeleton!");
            } else {
                player.sendMessage(ChatColor.RED + "Transform ability is on cooldown!");
            }
            return;
        }

        if (!player.isSneaking() && (action == Action.RIGHT_CLICK_AIR || action == Action.RIGHT_CLICK_BLOCK)) {
            if (isCooldownOver(playerId, soulHarvestCooldown, SOUL_HARVEST_COOLDOWN_SECONDS)) {
                activateSoulHarvest(player);
                soulHarvestCooldown.put(playerId, System.currentTimeMillis());
                player.sendMessage(ChatColor.DARK_PURPLE + "Soul Harvest activated!");
            } else {
                player.sendMessage(ChatColor.RED + "Soul Harvest is on cooldown!");
            }
        }
    }

    private boolean isCooldownOver(UUID playerId, HashMap<UUID, Long> cooldownMap, int cooldownSeconds) {
        return !cooldownMap.containsKey(playerId) ||
                (System.currentTimeMillis() - cooldownMap.get(playerId)) / 1000 >= cooldownSeconds;
    }

    private void summonWolves(Player player) {
        for (int i = 0; i < 3; i++) {
            Location spawnLocation = player.getLocation().add((i - 1) * 2, 0, (i - 1) * 2);
            Wolf wolf = player.getWorld().spawn(spawnLocation, Wolf.class);
            wolf.setOwner(player);
            wolf.setCustomName(player.getName() + "'s Wolf");
            wolf.setCustomNameVisible(true);
            wolf.setAdult();
            wolf.setHealth(20.0);
            wolf.setTamed(true);
        }
    }

    private void transformIntoSkeleton(Player player) {
        player.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, 20 * 15, 1));
        player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 20 * 15, 1));
        player.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION, 20 * 15, 1));

        for (int i = 0; i < 10; i++) {
            double angle = Math.toRadians(i * 36);
            double x = Math.cos(angle) * 1.5;
            double z = Math.sin(angle) * 1.5;
            player.getWorld().spawnParticle(Particle.SMOKE, player.getLocation().add(x, 0, z), 5);
        }

        new BukkitRunnable() {
            @Override
            public void run() {
                player.removePotionEffect(PotionEffectType.INVISIBILITY);
                player.removePotionEffect(PotionEffectType.SPEED);
                player.removePotionEffect(PotionEffectType.NIGHT_VISION);
                player.sendMessage(ChatColor.YELLOW + "You have transformed back!");
            }
        }.runTaskLater(plugin, 20 * 15);
    }

    private void activateSoulHarvest(Player player) {
        Location playerLocation = player.getLocation();
        World world = player.getWorld();
        int radius = 5;
        final int duration = 5;
        final double tickDamage = 0.5;

        new BukkitRunnable() {
            int ticksElapsed = 0;

            @Override
            public void run() {
                if (ticksElapsed >= duration * 20) {
                    cancel();
                    return;
                }

                for (Entity entity : world.getNearbyEntities(playerLocation, radius, radius, radius)) {
                    if (entity instanceof LivingEntity && entity != player) {
                        ((LivingEntity) entity).damage(tickDamage);
                    }
                }

                ticksElapsed++;
            }
        }.runTaskTimer(plugin, 0, 1);
    }
}
