package org.AlexGems.sPG;

import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.CommandExecutor;
import org.bukkit.ChatColor;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class SPG extends JavaPlugin implements CommandExecutor {
    private List<String> classes;
    private Random random;
    private Necromancer necromancer;
    private ShadeWalker shadeWalker;

    @Override
    public void onEnable() {
        random = new Random();
        classes = new ArrayList<>();
        classes.add("Necromancer");
        classes.add("ShadeWalker");
        necromancer = new Necromancer(this);
        shadeWalker = new ShadeWalker(this);
        this.getCommand("randomclass").setExecutor(this);
        getServer().getPluginManager().registerEvents(necromancer, this);
        getServer().getPluginManager().registerEvents(shadeWalker, this);
        getLogger().info("SPG plugin enabled!");
    }

    @Override
    public void onDisable() {
        getLogger().info("SPG plugin disabled!");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("This command can only be used by players!");
            return true;
        }

        Player player = (Player) sender;

        if (command.getName().equalsIgnoreCase("randomclass")) {
            necromancer.getHasClassMap().remove(player.getUniqueId());
            shadeWalker.getHasClassMap().remove(player.getUniqueId());

            String randomClass = pickRandomClass();
            player.sendMessage(ChatColor.GREEN + "Your random class is: " + randomClass);

            switch (randomClass) {
                case "Necromancer":
                    necromancer.getHasClassMap().put(player.getUniqueId(), true);
                    player.sendMessage(ChatColor.DARK_PURPLE + "You are now a Necromancer! Use your abilities wisely!");
                    player.sendMessage(ChatColor.GRAY + "Abilities:");
                    player.sendMessage(ChatColor.GRAY + "- Shift + Right Click: Summon Wolves");
                    player.sendMessage(ChatColor.GRAY + "- Shift + Left Click: Transform into Skeleton");
                    player.sendMessage(ChatColor.GRAY + "- Right Click: Soul Harvest");
                    break;

                case "ShadeWalker":
                    shadeWalker.getHasClassMap().put(player.getUniqueId(), true);
                    player.sendMessage(ChatColor.DARK_GRAY + "You are now a ShadeWalker! Master the shadows!");
                    player.sendMessage(ChatColor.GRAY + "Abilities:");
                    player.sendMessage(ChatColor.GRAY + "- Right Click: Cast Darkness");
                    player.sendMessage(ChatColor.GRAY + "- Shift + Left Click: Disable Movement");
                    player.sendMessage(ChatColor.GRAY + "- Shift + Right Click: Transform Blocks to Sculk");
                    break;
            }

            return true;
        }
        return false;
    }

    private String pickRandomClass() {
        int index = random.nextInt(classes.size());
        return classes.get(index);
    }
}
