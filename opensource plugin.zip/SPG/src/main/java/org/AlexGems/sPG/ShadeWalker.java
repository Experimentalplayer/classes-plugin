package org.AlexGems.sPG;

import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.Listener;
import org.bukkit.event.EventHandler;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.ChatColor;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class ShadeWalker implements Listener {
    private final HashMap<UUID, Long> darknessCooldown = new HashMap<>();
    private final HashMap<UUID, Long> disableMovementCooldown = new HashMap<>();
    private final HashMap<UUID, Long> sculkTransformCooldown = new HashMap<>();
    private final Map<Location, Material> originalBlocks = new HashMap<>();
    private final HashMap<UUID, Boolean> hasClass = new HashMap<>();
    private final SPG plugin;

    private static final int DARKNESS_COOLDOWN_SECONDS = 30;
    private static final int DISABLE_MOVEMENT_COOLDOWN_SECONDS = 20;
    private static final int SCULK_TRANSFORM_COOLDOWN_SECONDS = 60;

    public ShadeWalker(SPG plugin) {
        this.plugin = plugin;
    }

    public HashMap<UUID, Boolean> getHasClassMap() {
        return hasClass;
    }

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        UUID playerId = player.getUniqueId();
        Action action = event.getAction();

        if (!hasClass.getOrDefault(playerId, false)) {
            return;
        }

        if (!player.isSneaking()) {
            if (action == Action.RIGHT_CLICK_AIR || action == Action.RIGHT_CLICK_BLOCK) {
                if (isCooldownOver(playerId, darknessCooldown, DARKNESS_COOLDOWN_SECONDS)) {
                    applyDarknessEffect(player);
                    darknessCooldown.put(playerId, System.currentTimeMillis());
                    player.sendMessage(ChatColor.DARK_GRAY + "You have cast Darkness!");
                } else {
                    player.sendMessage(ChatColor.RED + "Darkness ability is on cooldown!");
                }
                return;
            }
        } else {
            if (action == Action.LEFT_CLICK_AIR || action == Action.LEFT_CLICK_BLOCK) {
                if (isCooldownOver(playerId, disableMovementCooldown, DISABLE_MOVEMENT_COOLDOWN_SECONDS)) {
                    disableNearbyMovement(player);
                    disableMovementCooldown.put(playerId, System.currentTimeMillis());
                    player.sendMessage(ChatColor.GRAY + "You have disabled movement nearby!");
                } else {
                    player.sendMessage(ChatColor.RED + "Disable Movement ability is on cooldown!");
                }
                return;
            }

            if (action == Action.RIGHT_CLICK_AIR || action == Action.RIGHT_CLICK_BLOCK) {
                if (isCooldownOver(playerId, sculkTransformCooldown, SCULK_TRANSFORM_COOLDOWN_SECONDS)) {
                    transformNearbyBlocksToSculk(player);
                    sculkTransformCooldown.put(playerId, System.currentTimeMillis());
                    player.sendMessage(ChatColor.GREEN + "You have transformed blocks into Sculk!");
                } else {
                    player.sendMessage(ChatColor.RED + "Sculk Transform ability is on cooldown!");
                }
            }
        }
    }

    private boolean isCooldownOver(UUID playerId, HashMap<UUID, Long> cooldownMap, int cooldownSeconds) {
        return !cooldownMap.containsKey(playerId) ||
                (System.currentTimeMillis() - cooldownMap.get(playerId)) / 1000 >= cooldownSeconds;
    }

    private void applyDarknessEffect(Player player) {
        Location playerLocation = player.getLocation();
        for (Player nearbyPlayer : player.getWorld().getPlayers()) {
            if (nearbyPlayer.getLocation().distance(playerLocation) <= 10) {
                nearbyPlayer.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 20 * 15, 1));
                if (nearbyPlayer != player) {
                    nearbyPlayer.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 20 * 15, 1));
                }
                spawnFancyParticles(nearbyPlayer.getLocation(), Particle.SMOKE);
            }
        }
        player.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, 20 * 15, 1));
        spawnFancyParticles(playerLocation, Particle.END_ROD);
        player.getWorld().playSound(playerLocation, Sound.ENTITY_WITHER_SPAWN, 1.0f, 1.0f);
    }

    private void disableNearbyMovement(Player player) {
        Location playerLocation = player.getLocation();
        for (Entity entity : player.getNearbyEntities(10, 10, 10)) {
            if (entity instanceof Player) {
                Player nearbyPlayer = (Player) entity;
                nearbyPlayer.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 20 * 1, 100, false, false));
                spawnFancyParticles(nearbyPlayer.getLocation(), Particle.SOUL_FIRE_FLAME);
            }
        }
        player.getWorld().playSound(playerLocation, Sound.ENTITY_PLAYER_BREATH, 1.0f, 1.0f);
    }

    private void transformNearbyBlocksToSculk(Player player) {
        Location playerLocation = player.getLocation();
        int radius = 20;

        for (int x = -radius; x <= radius; x++) {
            for (int z = -radius; z <= radius; z++) {
                for (int y = -1; y <= 1; y++) {
                    Location blockLocation = playerLocation.clone().add(x, y, z);
                    if (blockLocation.getBlock().getType() != Material.AIR) {
                        originalBlocks.put(blockLocation.clone(), blockLocation.getBlock().getType());
                        blockLocation.getBlock().setType(Material.SCULK_SENSOR);
                    }
                }
            }
        }

        new BukkitRunnable() {
            @Override
            public void run() {
                for (Map.Entry<Location, Material> entry : originalBlocks.entrySet()) {
                    entry.getKey().getBlock().setType(entry.getValue());
                    spawnFancyParticles(entry.getKey(), Particle.HAPPY_VILLAGER);
                }
                originalBlocks.clear();
            }
        }.runTaskLater(plugin, 20 * 30);

        spawnFancyParticles(playerLocation, Particle.SQUID_INK);
        player.getWorld().playSound(playerLocation, Sound.BLOCK_SCULK_SENSOR_PLACE, 1.0f, 1.0f);
    }

    private void spawnFancyParticles(Location location, Particle particle) {
        location.getWorld().spawnParticle(particle, location, 30, 0.5, 0.5, 0.5, 0.1);
    }
}