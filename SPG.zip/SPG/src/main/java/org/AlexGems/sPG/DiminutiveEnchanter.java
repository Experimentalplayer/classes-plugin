package org.AlexGems.sPG;

import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.*;
import org.bukkit.event.Listener;
import org.bukkit.event.EventHandler;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.entity.EntitySpawnEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.ChatColor;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.util.Vector;
import org.bukkit.event.entity.EntityDamageByEntityEvent;


import java.util.HashMap;
import java.util.Random;
import java.util.UUID;

public class DiminutiveEnchanter implements Listener {
    private final HashMap<UUID, Long> shrinkCooldown = new HashMap<>();
    private final HashMap<UUID, Long> enlargeCooldown = new HashMap<>();
    private final HashMap<UUID, Long> mobEnlargeCooldown = new HashMap<>();
    private final HashMap<UUID, Boolean> hasClass = new HashMap<>();
    private final SPG plugin;

    // Cooldown settings
    private static final int SHRINK_COOLDOWN_SECONDS = 10;
    private static final int ENLARGE_COOLDOWN_SECONDS = 10;
    private static final int MOB_ENLARGE_COOLDOWN_SECONDS = 300; // 5 minutes
    private final HashMap<UUID, String> currentSizeState = new HashMap<>();

    public DiminutiveEnchanter(SPG plugin) {
        this.plugin = plugin;
        startParticleEffectTask();
    }

    public HashMap<UUID, Boolean> getHasClassMap() {
        return hasClass;
    }

    private void startParticleEffectTask() {
        new BukkitRunnable() {
            @Override
            public void run() {
                for (World world : Bukkit.getWorlds()) {
                    for (Entity entity : world.getEntities()) {
                        if (entity.hasMetadata("size")) {
                            float size = entity.getMetadata("size").get(0).asFloat();
                            Location loc = entity.getLocation();

                            if (size < 1.0) { // Shrunk entities
                                world.spawnParticle(Particle.WITCH, loc.add(0, 0.5, 0), 1, 0.2, 0.2, 0.2, 0);
                                world.spawnParticle(Particle.PORTAL, loc, 2, 0.1, 0.1, 0.1, 0.05);
                            } else if (size > 1.0) { // Enlarged entities
                                world.spawnParticle(Particle.FLAME, loc.add(0, 1, 0), 2, 0.3, 0.5, 0.3, 0.01);
                                world.spawnParticle(Particle.LAVA, loc, 1, 0.2, 0.2, 0.2, 0);
                            }
                        }
                    }
                }
            }
        }.runTaskTimer(plugin, 0L, 5L); // Run every 5 ticks
    }

    @EventHandler
    public void onEntitySpawn(EntitySpawnEvent event) {
        Entity entity = event.getEntity();
        if (entity.hasMetadata("size")) {
            float size = entity.getMetadata("size").get(0).asFloat();
            applyEntitySize(entity, size);
        }
    }

    @EventHandler
    public void onCreatureSpawn(CreatureSpawnEvent event) {
        Entity entity = event.getEntity();
        if (entity.hasMetadata("size")) {
            float size = entity.getMetadata("size").get(0).asFloat();
            applyEntitySize(entity, size);
        }
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        if (player.hasMetadata("size")) {
            float size = player.getMetadata("size").get(0).asFloat();
            applyEntitySize(player, size);
        }
    }

    private void applyEntitySize(Entity entity, float size) {
        // Apply size effects
        if (entity instanceof LivingEntity) {
            LivingEntity livingEntity = (LivingEntity) entity;

            // Adjust hitbox and other properties
            livingEntity.setCustomName(getCustomNameForSize(livingEntity, size));
            livingEntity.setCustomNameVisible(true);

            // Special effects based on size
            if (size < 1.0) {
                if (livingEntity instanceof Player) {
                    Player player = (Player) livingEntity;
                    player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 200, 2));
                    player.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST, 200, 1));
                }
            } else if (size > 1.0) {
                livingEntity.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, 200, 1));
                if (livingEntity instanceof Player) {
                    Player player = (Player) livingEntity;
                    player.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 200, 0));
                }
            }

            // Particle effects
            createSizeChangeEffect(entity.getLocation(), size);
        }
    }

    private String getCustomNameForSize(LivingEntity entity, float size) {
        String baseName = entity instanceof Player ? entity.getName() :
                entity.getCustomName() != null ? entity.getCustomName() :
                        entity.getType().toString().toLowerCase();

        if (size < 1.0) {
            return ChatColor.AQUA + "Tiny " + baseName;
        } else if (size > 1.0) {
            return ChatColor.RED + "Giant " + baseName;
        }
        return baseName;
    }

    private void createSizeChangeEffect(Location location, float size) {
        World world = location.getWorld();
        if (world == null) return;

        // Create a helix effect
        new BukkitRunnable() {
            double phi = 0;
            @Override
            public void run() {
                phi += Math.PI/8;
                for (double t = 0; t <= 2*Math.PI; t += Math.PI/8) {
                    double x = 0.5 * Math.cos(t);
                    double z = 0.5 * Math.sin(t);
                    double y = 0.1 * phi;

                    Location particleLoc = location.clone().add(x, y, z);

                    if (size < 1.0) {
                        world.spawnParticle(Particle.WITCH, particleLoc, 1, 0, 0, 0, 0);
                        world.spawnParticle(Particle.PORTAL, particleLoc, 1, 0, 0, 0, 0);
                    } else {
                        world.spawnParticle(Particle.FLAME, particleLoc, 1, 0, 0, 0, 0);
                        world.spawnParticle(Particle.LAVA, particleLoc, 1, 0, 0, 0, 0);
                    }
                }

                if (phi > 4*Math.PI) {
                    this.cancel();
                }
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        UUID playerId = player.getUniqueId();
        Action action = event.getAction();

        if (!hasClass.getOrDefault(playerId, false)) {
            return;
        }

        String currentState = currentSizeState.getOrDefault(playerId, "normal");
        if (!currentState.equals("normal")) {
            player.sendMessage(ChatColor.RED + "⏳ Cannot change size while already transformed!");
            return;
        }

        if (player.isSneaking()) {
            if (action == Action.LEFT_CLICK_AIR || action == Action.LEFT_CLICK_BLOCK) {
                if (isCooldownOver(playerId, shrinkCooldown, SHRINK_COOLDOWN_SECONDS)) {
                    shrinkPlayer(player);
                    shrinkCooldown.put(playerId, System.currentTimeMillis());
                    currentSizeState.put(playerId, "small");
                    playCooldownAnimation(player, SHRINK_COOLDOWN_SECONDS);
                } else {
                    showCooldownMessage(player, "Shrink", shrinkCooldown.get(playerId), SHRINK_COOLDOWN_SECONDS);
                }
            } else if (action == Action.RIGHT_CLICK_AIR || action == Action.RIGHT_CLICK_BLOCK) {
                if (isCooldownOver(playerId, enlargeCooldown, ENLARGE_COOLDOWN_SECONDS)) {
                    enlargePlayer(player);
                    enlargeCooldown.put(playerId, System.currentTimeMillis());
                    currentSizeState.put(playerId, "large");
                    playCooldownAnimation(player, ENLARGE_COOLDOWN_SECONDS);
                } else {
                    showCooldownMessage(player, "Enlarge", enlargeCooldown.get(playerId), ENLARGE_COOLDOWN_SECONDS);
                }
            }
        }
    }

    @EventHandler
    public void onPlayerInteractEntity(PlayerInteractEntityEvent event) {
        Player player = event.getPlayer();
        UUID playerId = player.getUniqueId();

        if (!hasClass.getOrDefault(playerId, false)) {
            return;
        }

        if (player.getInventory().getItemInMainHand().getType() == Material.AIR) {
            if (isCooldownOver(playerId, mobEnlargeCooldown, MOB_ENLARGE_COOLDOWN_SECONDS)) {
                if (event.getRightClicked() instanceof LivingEntity && !(event.getRightClicked() instanceof Player)) {
                    enlargeMob((LivingEntity) event.getRightClicked());
                    mobEnlargeCooldown.put(playerId, System.currentTimeMillis());
                    player.sendMessage(ChatColor.GREEN + "§l⚔ Target enlarged!");
                    playCooldownAnimation(player, MOB_ENLARGE_COOLDOWN_SECONDS);
                }
            } else {
                showCooldownMessage(player, "Mob Enlarge", mobEnlargeCooldown.get(playerId), MOB_ENLARGE_COOLDOWN_SECONDS);
            }
        }
    }

    private void shrinkPlayer(Player player) {
        // Set the scale using command
        Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "attribute " + player.getName() + " minecraft:generic.scale base set 0.5");

        // Reduce health and modify display
        double originalMaxHealth = player.getAttribute(Attribute.GENERIC_MAX_HEALTH).getBaseValue();
        player.getAttribute(Attribute.GENERIC_MAX_HEALTH).setBaseValue(originalMaxHealth * 0.5);
        player.setHealth(Math.min(player.getHealth(), player.getAttribute(Attribute.GENERIC_MAX_HEALTH).getBaseValue()));

        // Force single row of hearts
        player.setHealthScale(20.0);

        applyEntitySize(player, 0.3f);
        player.sendMessage(ChatColor.AQUA + "§l↓ You have been shrunk!");

        // Reset after 10 seconds
        new BukkitRunnable() {
            @Override
            public void run() {
                // Reset the scale and max health back to default
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "attribute " + player.getName() + " minecraft:generic.scale base set 1");
                player.getAttribute(Attribute.GENERIC_MAX_HEALTH).setBaseValue(originalMaxHealth);
                player.setHealthScale(20.0); // Reset health scale
                applyEntitySize(player, 1.0f);
                player.getWorld().playSound(player.getLocation(), Sound.BLOCK_BEACON_ACTIVATE, 1.0f, 1.0f);
                currentSizeState.put(player.getUniqueId(), "normal");
            }
        }.runTaskLater(plugin, 200L);
    }


    private void enlargePlayer(Player player) {
        // Set the scale using command
        Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "attribute " + player.getName() + " minecraft:generic.scale base set 2");

        // Increase health and modify display
        double originalMaxHealth = player.getAttribute(Attribute.GENERIC_MAX_HEALTH).getBaseValue();
        player.getAttribute(Attribute.GENERIC_MAX_HEALTH).setBaseValue(originalMaxHealth * 2);
        player.setHealth(player.getAttribute(Attribute.GENERIC_MAX_HEALTH).getBaseValue());

        // Force single row of hearts
        player.setHealthScale(40.0);

        applyEntitySize(player, 3.0f);
        player.sendMessage(ChatColor.RED + "§l↑ You have been enlarged!");

        // Reset after 10 seconds
        new BukkitRunnable() {
            @Override
            public void run() {
                // Reset the scale and max health back to default
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "attribute " + player.getName() + " minecraft:generic.scale base set 1");
                player.getAttribute(Attribute.GENERIC_MAX_HEALTH).setBaseValue(originalMaxHealth);
                player.setHealthScale(20.0); // Reset health scale
                applyEntitySize(player, 1.0f);
                player.getWorld().playSound(player.getLocation(), Sound.BLOCK_BEACON_ACTIVATE, 1.0f, 1.0f);
                currentSizeState.put(player.getUniqueId(), "normal");
            }
        }.runTaskLater(plugin, 200L);
    }

    private void enlargeMob(LivingEntity entity) {
        // Apply size and effect changes
        entity.setMaxHealth(entity.getMaxHealth() * 5); // Triple health
        entity.setHealth(entity.getMaxHealth()); // Heal to full

        // Set the size attribute
        AttributeInstance scaleAttribute = entity.getAttribute(Attribute.GENERIC_SCALE);
        if (scaleAttribute != null) {
            scaleAttribute.setBaseValue(15); // Set size to 5
        }

        // Apply random buffs
        Random random = new Random();
        PotionEffectType[] possibleEffects = {
                PotionEffectType.STRENGTH,
                PotionEffectType.SPEED,
                PotionEffectType.RESISTANCE,
                PotionEffectType.REGENERATION,
                PotionEffectType.FIRE_RESISTANCE
        };

        // Apply 2-3 random effects
        int numEffects = random.nextInt(2) + 2;
        for (int i = 0; i < numEffects; i++) {
            PotionEffectType effect = possibleEffects[random.nextInt(possibleEffects.length)];
            entity.addPotionEffect(new PotionEffect(effect, Integer.MAX_VALUE, random.nextInt(2) + 1));
        }

        // Visual and sound effects
        entity.getWorld().spawnParticle(Particle.EXPLOSION, entity.getLocation(), 1);
        entity.getWorld().spawnParticle(Particle.FLAME, entity.getLocation(), 50, 0.5, 1, 0.5, 0.1);
        entity.getWorld().playSound(entity.getLocation(), Sound.ENTITY_WITHER_SPAWN, 1.0f, 0.5f);
    }

    private void showCooldownMessage(Player player, String abilityName, long lastUsed, int cooldownSeconds) {
        long timeLeft = cooldownSeconds - (System.currentTimeMillis() - lastUsed) / 1000;
        player.sendMessage(ChatColor.RED + "⏳ " + abilityName + " cooling down: " + timeLeft + "s remaining");
    }

    private void playCooldownAnimation(Player player, int duration) {
        new BukkitRunnable() {
            final Location loc = player.getLocation();
            double t = 0;

            @Override
            public void run() {
                t += 0.1;
                if (t > duration) {
                    this.cancel();
                    return;
                }

                double x = Math.cos(t * 2) * 0.5;
                double z = Math.sin(t * 2) * 0.5;
                loc.add(x, 0, z);
                player.spawnParticle(Particle.PORTAL, loc, 1, 0, 0, 0, 0);
                loc.subtract(x, 0, z);
            }
        }.runTaskTimer(plugin, 0L, 2L);
    }

    private boolean isCooldownOver(UUID playerId, HashMap<UUID, Long> cooldownMap, int cooldownSeconds) {
        return !cooldownMap.containsKey(playerId) ||
                (System.currentTimeMillis() - cooldownMap.get(playerId)) / 1000 >= cooldownSeconds;
    }
}