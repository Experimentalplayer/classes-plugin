package org.AlexGems.sPG;

import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.Listener;
import org.bukkit.event.EventHandler;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;
import org.bukkit.ChatColor;

import java.util.HashMap;
import java.util.UUID;
import java.util.ArrayList;
import java.util.List;

public class ArenaChampion implements Listener {
    private final SPG plugin;
    private final HashMap<UUID, Boolean> hasClass = new HashMap<>();
    private final HashMap<UUID, Long> arenaTrapCooldown = new HashMap<>();
    private final HashMap<UUID, Long> spectatorMightCooldown = new HashMap<>();
    private final HashMap<UUID, Long> championsResurgenceCooldown = new HashMap<>();
    private final HashMap<UUID, Player> trappedPlayers = new HashMap<>();  // Keep this for backwards compatibility
    private final HashMap<UUID, List<UUID>> trappedEntities = new HashMap<>();
    private final HashMap<UUID, Location> arenaCenters = new HashMap<>();
    private final HashMap<UUID, List<BukkitRunnable>> activeParticleTasks = new HashMap<>();
    private final HashMap<UUID, BukkitRunnable> movementTasks = new HashMap<>();

    private static final int ARENA_TRAP_COOLDOWN_SECONDS = 60;
    private static final int SPECTATOR_MIGHT_COOLDOWN_SECONDS = 30;
    private static final int CHAMPIONS_RESURGENCE_COOLDOWN_SECONDS = 30;
    private static final int ARENA_DURATION_TICKS = 200;
    private static final double TRAP_RADIUS = 5.0;
    private static final double TRAP_HEIGHT = 5.0;

    public ArenaChampion(SPG plugin) {
        this.plugin = plugin;
    }

    public HashMap<UUID, Boolean> getHasClassMap() {
        return hasClass;
    }

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        UUID playerId = player.getUniqueId();
        Action action = event.getAction();

        if (!hasClass.getOrDefault(playerId, false)) {
            return;
        }

        boolean isHoldingNothing = player.getInventory().getItemInMainHand().getType() == Material.AIR;

        if (!player.isSneaking()) {
            if ((action == Action.RIGHT_CLICK_AIR || action == Action.RIGHT_CLICK_BLOCK) && isHoldingNothing) {
                if (isCooldownOver(playerId, arenaTrapCooldown, ARENA_TRAP_COOLDOWN_SECONDS)) {
                    createArenaTrap(player);
                    arenaTrapCooldown.put(playerId, System.currentTimeMillis());
                    player.sendMessage(ChatColor.GOLD + "You have created an Arena Trap!");
                } else {
                    player.sendMessage(ChatColor.RED + "Arena Trap ability is on cooldown!");
                }
            }
        } else {
            if (action == Action.LEFT_CLICK_AIR || action == Action.LEFT_CLICK_BLOCK) {
                if (isCooldownOver(playerId, spectatorMightCooldown, SPECTATOR_MIGHT_COOLDOWN_SECONDS)) {
                    empowerAttacks(player);
                    spectatorMightCooldown.put(playerId, System.currentTimeMillis());
                    player.sendMessage(ChatColor.GOLD + "You have empowered your attacks!");
                } else {
                    player.sendMessage(ChatColor.RED + "Spectator's Might ability is on cooldown!");
                }
            } else if ((action == Action.RIGHT_CLICK_AIR || action == Action.RIGHT_CLICK_BLOCK) && isHoldingNothing) {
                if (isCooldownOver(playerId, championsResurgenceCooldown, CHAMPIONS_RESURGENCE_COOLDOWN_SECONDS)) {
                    rejuvenate(player);
                    championsResurgenceCooldown.put(playerId, System.currentTimeMillis());
                    player.sendMessage(ChatColor.GOLD + "You have rejuvenated your health!");
                } else {
                    player.sendMessage(ChatColor.RED + "Champion's Resurgence ability is on cooldown!");
                }
            }
        }
    }

    private void createArenaTrap(Player player) {
        Location center = player.getLocation();
        UUID playerId = player.getUniqueId();

        // Store arena center
        arenaCenters.put(playerId, center);

        // Initialize trapped entities list
        trappedEntities.put(playerId, new ArrayList<>());

        // Create particle walls
        ArrayList<BukkitRunnable> particleTasks = new ArrayList<>();
        createParticleWalls(center, particleTasks);

        // Store and manage particle tasks
        List<BukkitRunnable> existingTasks = activeParticleTasks.get(playerId);
        if (existingTasks != null) {
            existingTasks.forEach(BukkitRunnable::cancel);
        }
        activeParticleTasks.put(playerId, particleTasks);

        // Trap nearby entities
        for (Entity entity : player.getNearbyEntities(TRAP_RADIUS, TRAP_HEIGHT, TRAP_RADIUS)) {
            if ((entity instanceof Player || entity instanceof Monster) && entity != player) {
                UUID entityId = entity.getUniqueId();
                trappedEntities.get(playerId).add(entityId);

                if (entity instanceof Player) {
                    Player trapped = (Player) entity;
                    trappedPlayers.put(trapped.getUniqueId(), player);  // Maintain backwards compatibility
                    trapped.sendMessage(ChatColor.RED + "You have been trapped in an arena by " + player.getName() + "!");
                    player.sendMessage(ChatColor.GREEN + "You trapped " + trapped.getName() + "!");
                    applyArenaEffects(trapped, player);
                }
            }
        }

        // Start movement restriction task
        startMovementTask(player);

        // Schedule arena cleanup
        new BukkitRunnable() {
            @Override
            public void run() {
                cleanupArena(playerId);
            }
        }.runTaskLater(plugin, ARENA_DURATION_TICKS);
    }

    private void createParticleWalls(Location center, ArrayList<BukkitRunnable> particleTasks) {
        for (int angle = 0; angle < 360; angle += 10) {
            final int finalAngle = angle;
            BukkitRunnable particleTask = new BukkitRunnable() {
                @Override
                public void run() {
                    double radians = Math.toRadians(finalAngle);
                    double x = center.getX() + TRAP_RADIUS * Math.cos(radians);
                    double z = center.getZ() + TRAP_RADIUS * Math.sin(radians);

                    for (double y = 0; y <= TRAP_HEIGHT; y += 0.5) {
                        Location wallLocation = new Location(center.getWorld(), x, center.getY() + y, z);
                        center.getWorld().spawnParticle(Particle.END_ROD, wallLocation, 1, 0, 0, 0, 0);
                    }
                }
            };

            particleTask.runTaskTimer(plugin, 0, 2);
            particleTasks.add(particleTask);
        }
    }

    private void applyArenaEffects(Player opponent, Player champion) {
        opponent.setInvulnerable(true);

        // Apply damage and healing
        opponent.setHealth(Math.max(0, opponent.getHealth() - 4));
        champion.setHealth(Math.min(champion.getHealth() + 4, champion.getMaxHealth()));
    }

    private void startMovementTask(Player champion) {
        UUID champId = champion.getUniqueId();

        // Cancel existing movement task if it exists
        BukkitRunnable existingTask = movementTasks.get(champId);
        if (existingTask != null) {
            existingTask.cancel();
        }

        BukkitRunnable movementTask = new BukkitRunnable() {
            @Override
            public void run() {
                if (!arenaCenters.containsKey(champId)) {
                    cancel();
                    return;
                }

                Location center = arenaCenters.get(champId);
                List<UUID> trapped = trappedEntities.get(champId);

                if (trapped != null) {
                    for (UUID entityId : trapped) {
                        Entity entity = Bukkit.getEntity(entityId);
                        if (entity != null && entity.isValid()) {
                            enforceArenaBoundary(entity, center);
                        }
                    }
                }
            }
        };

        movementTask.runTaskTimer(plugin, 0, 1);
        movementTasks.put(champId, movementTask);
    }

    private void enforceArenaBoundary(Entity entity, Location center) {
        if (entity.getLocation().distance(center) > TRAP_RADIUS) {
            Location entityLoc = entity.getLocation();
            Vector direction = entityLoc.toVector().subtract(center.toVector()).normalize();
            Location newLoc = center.clone().add(direction.multiply(TRAP_RADIUS));
            newLoc.setY(entityLoc.getY());
            newLoc.setPitch(entityLoc.getPitch());
            newLoc.setYaw(entityLoc.getYaw());

            // Apply smooth pushback
            Vector pushback = center.toVector().subtract(entityLoc.toVector()).normalize();
            entity.setVelocity(pushback.multiply(0.5));

            // Teleport as fallback if entity somehow gets too far
            if (entity.getLocation().distance(center) > TRAP_RADIUS * 1.5) {
                entity.teleport(newLoc);
            }
        }
    }

    private void cleanupArena(UUID champId) {
        // Cancel and remove particle tasks
        List<BukkitRunnable> particleTasks = activeParticleTasks.remove(champId);
        if (particleTasks != null) {
            particleTasks.forEach(BukkitRunnable::cancel);
        }

        // Cancel movement task
        BukkitRunnable movementTask = movementTasks.remove(champId);
        if (movementTask != null) {
            movementTask.cancel();
        }

        // Free trapped entities
        List<UUID> trapped = trappedEntities.remove(champId);
        if (trapped != null) {
            trapped.forEach(entityId -> {
                Entity entity = Bukkit.getEntity(entityId);
                if (entity instanceof Player) {
                    Player player = (Player) entity;
                    player.setInvulnerable(false);
                    trappedPlayers.remove(player.getUniqueId());  // Clean up trappedPlayers map
                    player.sendMessage(ChatColor.GREEN + "You have escaped the arena!");
                }
            });
        }

        // Remove arena center
        arenaCenters.remove(champId);

        // Notify champion
        Player champion = Bukkit.getPlayer(champId);
        if (champion != null && champion.isOnline()) {
            champion.sendMessage(ChatColor.GREEN + "Your arena has dissipated!");
        }
    }

    private void empowerAttacks(Player player) {
        player.sendMessage(ChatColor.GREEN + "Your attacks now deal double damage for 5 seconds!");
        spawnFancyParticles(player.getLocation(), Particle.END_ROD);

        new BukkitRunnable() {
            @Override
            public void run() {
                player.sendMessage(ChatColor.GREEN + "Your double damage has ended.");
            }
        }.runTaskLater(plugin, 100);
    }

    private void rejuvenate(Player player) {
        double healAmount = 4;
        if (trappedPlayers.containsKey(player.getUniqueId())) {
            healAmount *= 2;
        }
        player.setHealth(Math.min(player.getHealth() + healAmount, player.getMaxHealth()));
        player.sendMessage(ChatColor.GREEN + "You have restored your health!");
        spawnFancyParticles(player.getLocation(), Particle.HAPPY_VILLAGER);
    }

    private boolean isCooldownOver(UUID playerId, HashMap<UUID, Long> cooldownMap, int cooldownSeconds) {
        return !cooldownMap.containsKey(playerId) ||
                (System.currentTimeMillis() - cooldownMap.get(playerId)) / 1000 >= cooldownSeconds;
    }

    private void spawnFancyParticles(Location location, Particle particle) {
        for (int i = 0; i < 30; i++) {
            location.getWorld().spawnParticle(particle, location, 1, Math.random() - 0.5, Math.random() - 0.5, Math.random() - 0.5, 0.1);
        }
        location.getWorld().playSound(location, Sound.ENTITY_FIREWORK_ROCKET_BLAST, 1.0f, 1.0f);
    }
}