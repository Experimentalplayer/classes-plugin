package org.AlexGems.sPG;

import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.Listener;
import org.bukkit.event.EventHandler;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.ChatColor;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.UUID;

public class ShadeWalker implements Listener {
    private final HashMap<UUID, Long> darknessCooldown = new HashMap<>();
    private final HashMap<UUID, Long> disableMovementCooldown = new HashMap<>();
    private final HashMap<UUID, Long> shadowStepCooldown = new HashMap<>();
    private final HashMap<UUID, Boolean> hasClass = new HashMap<>();
    private final SPG plugin;

    // Adjusted cooldowns for better gameplay balance
    private static final int DARKNESS_COOLDOWN_SECONDS = 25;
    private static final int DISABLE_MOVEMENT_COOLDOWN_SECONDS = 15;
    private static final int SHADOW_STEP_COOLDOWN_SECONDS = 45;

    // New effect durations
    private static final int DARKNESS_DURATION = 12;
    private static final int MOVEMENT_DISABLE_DURATION = 3;

    public ShadeWalker(SPG plugin) {
        this.plugin = plugin;
    }

    public HashMap<UUID, Boolean> getHasClassMap() {
        return hasClass;
    }

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        UUID playerId = player.getUniqueId();
        Action action = event.getAction();

        if (!hasClass.getOrDefault(playerId, false)) {
            return;
        }

        // Check if the player is holding nothing
        boolean isHoldingNothing = player.getInventory().getItemInMainHand().getType() == Material.AIR;

        if (!player.isSneaking()) {
            // Require holding nothing for the right-click action
            if ((action == Action.RIGHT_CLICK_AIR || action == Action.RIGHT_CLICK_BLOCK) && isHoldingNothing) {
                if (isCooldownOver(playerId, darknessCooldown, DARKNESS_COOLDOWN_SECONDS)) {
                    applyDarknessEffect(player);
                    darknessCooldown.put(playerId, System.currentTimeMillis());
                    player.sendMessage(ChatColor.DARK_PURPLE + "§l⚔ Dark Veil Unleashed!");
                    playCooldownAnimation(player, DARKNESS_COOLDOWN_SECONDS);
                } else {
                    showCooldownMessage(player, "Darkness", darknessCooldown.get(playerId), DARKNESS_COOLDOWN_SECONDS);
                }
                return;
            }
        } else {
            if (action == Action.LEFT_CLICK_AIR || action == Action.LEFT_CLICK_BLOCK) {
                if (isCooldownOver(playerId, disableMovementCooldown, DISABLE_MOVEMENT_COOLDOWN_SECONDS)) {
                    disableNearbyMovement(player);
                    disableMovementCooldown.put(playerId, System.currentTimeMillis());
                    player.sendMessage(ChatColor.GRAY + "§l⚡ Shadow Binding Cast!");
                    playCooldownAnimation(player, DISABLE_MOVEMENT_COOLDOWN_SECONDS);
                } else {
                    showCooldownMessage(player, "Shadow Bind", disableMovementCooldown.get(playerId), DISABLE_MOVEMENT_COOLDOWN_SECONDS);
                }
                return;
            }

            if (action == Action.RIGHT_CLICK_AIR || action == Action.RIGHT_CLICK_BLOCK) {
                if (isCooldownOver(playerId, shadowStepCooldown, SHADOW_STEP_COOLDOWN_SECONDS)) {
                    teleportBehindNearest(player);
                    shadowStepCooldown.put(playerId, System.currentTimeMillis());
                    playCooldownAnimation(player, SHADOW_STEP_COOLDOWN_SECONDS);
                } else {
                    showCooldownMessage(player, "Shadow Step", shadowStepCooldown.get(playerId), SHADOW_STEP_COOLDOWN_SECONDS);
                }
            }
        }
    }

    private void showCooldownMessage(Player player, String abilityName, long lastUsed, int cooldownSeconds) {
        long timeLeft = cooldownSeconds - (System.currentTimeMillis() - lastUsed) / 1000;
        player.sendMessage(ChatColor.RED + "⏳ " + abilityName + " cooling down: " + timeLeft + "s remaining");
    }

    private void playCooldownAnimation(Player player, int duration) {
        new BukkitRunnable() {
            final Location loc = player.getLocation();
            double t = 0;

            @Override
            public void run() {
                t += 0.1;
                if (t > duration) {
                    this.cancel();
                    return;
                }

                double x = Math.cos(t * 2) * 0.5;
                double z = Math.sin(t * 2) * 0.5;
                loc.add(x, 0, z);
                player.spawnParticle(Particle.WITCH, loc, 1, 0, 0, 0, 0);
                loc.subtract(x, 0, z);
            }
        }.runTaskTimer(plugin, 0L, 2L);
    }

    private void applyDarknessEffect(Player player) {
        Location playerLocation = player.getLocation();
        World world = player.getWorld();

        // Create expanding darkness effect
        new BukkitRunnable() {
            double radius = 0;
            int ticks = 0;

            @Override
            public void run() {
                if (ticks > 20) {
                    this.cancel();
                    return;
                }

                for (double angle = 0; angle < Math.PI * 2; angle += Math.PI / 16) {
                    double x = Math.cos(angle) * radius;
                    double z = Math.sin(angle) * radius;
                    Location particleLoc = playerLocation.clone().add(x, 0.1, z);
                    world.spawnParticle(Particle.DRAGON_BREATH, particleLoc, 1, 0, 0, 0, 0);
                    world.spawnParticle(Particle.SMOKE, particleLoc, 1, 0, 0.2, 0, 0.02);
                }

                radius += 0.5;
                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 1L);

        // Apply effects to nearby players (but not the caster)
        for (Player nearbyPlayer : player.getWorld().getPlayers()) {
            if (!nearbyPlayer.equals(player) && nearbyPlayer.getLocation().distance(playerLocation) <= 12) {
                nearbyPlayer.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 20 * DARKNESS_DURATION, 1));
                nearbyPlayer.addPotionEffect(new PotionEffect(PotionEffectType.NAUSEA, 20 * (DARKNESS_DURATION - 3), 0));
                spawnDarkVortex(nearbyPlayer.getLocation());
            }
        }

        // Effects for the caster
        player.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION, 20 * DARKNESS_DURATION, 0));
        player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 20 * DARKNESS_DURATION, 1));
        world.playSound(playerLocation, Sound.ENTITY_WITHER_SPAWN, 1.0f, 0.5f);
        world.playSound(playerLocation, Sound.ENTITY_PHANTOM_AMBIENT, 1.0f, 0.7f);
    }

    private void spawnDarkVortex(Location location) {
        new BukkitRunnable() {
            double y = 0;
            int ticks = 0;

            @Override
            public void run() {
                if (ticks > 40) {
                    this.cancel();
                    return;
                }

                for (double angle = 0; angle < Math.PI * 2; angle += Math.PI / 8) {
                    double x = Math.cos(angle) * 0.8;
                    double z = Math.sin(angle) * 0.8;
                    Location particleLoc = location.clone().add(x, y, z);
                    location.getWorld().spawnParticle(Particle.WITCH, particleLoc, 1, 0, 0, 0, 0);
                }

                y += 0.1;
                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    private void disableNearbyMovement(Player player) {
        Location playerLocation = player.getLocation();
        World world = player.getWorld();

        // Create ground effect
        new BukkitRunnable() {
            int ticks = 0;

            @Override
            public void run() {
                if (ticks > 20) {
                    this.cancel();
                    return;
                }

                for (double radius = 0; radius <= 10; radius += 0.5) {
                    for (double angle = 0; angle < Math.PI * 2; angle += Math.PI / 16) {
                        double x = Math.cos(angle) * radius;
                        double z = Math.sin(angle) * radius;
                        Location particleLoc = playerLocation.clone().add(x, 0.1, z);
                        world.spawnParticle(Particle.SOUL_FIRE_FLAME, particleLoc, 1, 0, 0, 0, 0);
                        world.spawnParticle(Particle.ENCHANT, particleLoc, 1, 0, 0.5, 0, 0.02);
                    }
                }

                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 1L);

        // Apply effects to nearby entities
        for (Entity entity : player.getNearbyEntities(10, 10, 10)) {
            if (entity instanceof LivingEntity && !(entity instanceof ArmorStand)) {
                LivingEntity target = (LivingEntity) entity;
                target.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 20 * MOVEMENT_DISABLE_DURATION, 100, false, true));
                target.addPotionEffect(new PotionEffect(PotionEffectType.LEVITATION, 20, 0, false, true));
                spawnChains(target.getLocation());
            }
        }

        world.playSound(playerLocation, Sound.ENTITY_PLAYER_BREATH, 1.0f, 0.5f);
        world.playSound(playerLocation, Sound.BLOCK_CHAIN_BREAK, 1.0f, 0.7f);
    }

    private void spawnChains(Location location) {
        new BukkitRunnable() {
            double angle = 0;
            int ticks = 0;

            @Override
            public void run() {
                if (ticks > 20) {
                    this.cancel();
                    return;
                }

                for (double height = 0; height < 2; height += 0.2) {
                    double x = Math.cos(angle) * 0.5;
                    double z = Math.sin(angle) * 0.5;
                    Location particleLoc = location.clone().add(x, height, z);
                    location.getWorld().spawnParticle(Particle.CRIT, particleLoc, 1, 0, 0, 0, 0);
                }

                angle += Math.PI / 8;
                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    private void teleportBehindNearest(Player player) {
        Location playerLocation = player.getLocation();
        Entity target = null;
        double nearestDistance = Double.MAX_VALUE;

        for (Entity entity : player.getNearbyEntities(20, 20, 20)) {
            if (entity instanceof LivingEntity && !(entity instanceof ArmorStand)) {
                double distance = playerLocation.distance(entity.getLocation());
                if (distance < nearestDistance) {
                    nearestDistance = distance;
                    target = entity;
                }
            }
        }

        if (target != null) {
            Location targetLocation = target.getLocation();
            Vector direction = targetLocation.getDirection().multiply(-1).normalize().setY(0);
            Location teleportLocation = targetLocation.clone().add(direction.multiply(2));

            // Create shadow trail effect
            createShadowTrail(playerLocation, teleportLocation);

            // Teleport player
            player.teleport(teleportLocation);

            // Add effects
            player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 60, 2));
            player.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, 60, 1));

            // Play sounds
            player.getWorld().playSound(playerLocation, Sound.ENTITY_ENDERMAN_TELEPORT, 1.0f, 1.2f);
            player.getWorld().playSound(teleportLocation, Sound.ENTITY_PHANTOM_SWOOP, 1.0f, 1.5f);

            player.sendMessage(ChatColor.DARK_PURPLE + "§l☯ Shadow Step executed on " + target.getName() + "!");
        } else {
            player.sendMessage(ChatColor.RED + "No valid targets within range!");
        }
    }

    private void createShadowTrail(Location start, Location end) {
        new BukkitRunnable() {
            int particles = 20;
            int count = 0;

            @Override
            public void run() {
                if (count > particles) {
                    this.cancel();
                    return;
                }

                double progress = (double) count / particles;
                Location current = start.clone().add(
                        end.clone().subtract(start).multiply(progress)
                );

                current.getWorld().spawnParticle(Particle.DRAGON_BREATH, current, 5, 0.2, 0.2, 0.2, 0.02);
                current.getWorld().spawnParticle(Particle.WITCH, current, 3, 0.1, 0.1, 0.1, 0);

                count++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    private boolean isCooldownOver(UUID playerId, HashMap<UUID, Long> cooldownMap, int cooldownSeconds) {
        return !cooldownMap.containsKey(playerId) ||
                (System.currentTimeMillis() - cooldownMap.get(playerId)) / 1000 >= cooldownSeconds;
    }
}