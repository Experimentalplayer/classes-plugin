package org.AlexGems.sPG;

import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.entity.*;
import org.bukkit.event.Listener;
import org.bukkit.event.EventHandler;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;
import org.bukkit.ChatColor;

import java.util.HashMap;
import java.util.HashSet;
import java.util.UUID;

public class Polarity implements Listener {
    private final HashMap<UUID, Long> repelCooldown = new HashMap<>();
    private final HashMap<UUID, Long> attractCooldown = new HashMap<>();
    private final HashMap<UUID, Long> blockAttractCooldown = new HashMap<>();
    private final HashMap<UUID, Boolean> hasClass = new HashMap<>();
    private final HashMap<Location, BukkitRunnable> attractiveBlockTasks = new HashMap<>();
    private final HashSet<Location> attractiveBlocks = new HashSet<>();
    private final SPG plugin;

    // Cooldown settings
    private static final int REPEL_COOLDOWN_SECONDS = 15;
    private static final int ATTRACT_COOLDOWN_SECONDS = 20;
    private static final int BLOCK_ATTRACT_COOLDOWN_SECONDS = 30;

    // Force settings
    private static final double REPEL_STRENGTH = 0.3;
    private static final double ATTRACT_STRENGTH = 0.08;
    private static final double BLOCK_ATTRACT_STRENGTH = 0.05;
    private static final double EFFECT_RADIUS = 5.0;

    public Polarity(SPG plugin) {
        this.plugin = plugin;
        startPolarityEffectTask();
    }

    public HashMap<UUID, Boolean> getHasClassMap() {
        return hasClass;
    }

    private void startPolarityEffectTask() {
        new BukkitRunnable() {
            @Override
            public void run() {
                for (Location blockLoc : new HashSet<>(attractiveBlocks)) {
                    World world = blockLoc.getWorld();
                    if (world != null) {
                        world.spawnParticle(Particle.SOUL_FIRE_FLAME,
                                blockLoc.clone().add(0.5, 0.5, 0.5),
                                5, 0.3, 0.3, 0.3, 0);
                        world.spawnParticle(Particle.DRAGON_BREATH,
                                blockLoc.clone().add(0.5, 0.5, 0.5),
                                3, 0.2, 0.2, 0.2, 0);
                    }
                }
            }
        }.runTaskTimer(plugin, 0L, 5L);
    }

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        UUID playerId = player.getUniqueId();
        Action action = event.getAction();

        if (!hasClass.getOrDefault(playerId, false)) {
            return;
        }

        if (player.isSneaking()) {
            if (action == Action.LEFT_CLICK_AIR || action == Action.LEFT_CLICK_BLOCK) {
                handleRepel(player);
            } else if (action == Action.RIGHT_CLICK_AIR || action == Action.RIGHT_CLICK_BLOCK) {
                handleAttract(player);
            }
        } else if (action == Action.RIGHT_CLICK_BLOCK &&
                player.getInventory().getItemInMainHand().getType() == Material.AIR) {
            handleBlockAttract(player, event.getClickedBlock());
        }
    }

    private void handleRepel(Player player) {
        UUID playerId = player.getUniqueId();
        if (isCooldownOver(playerId, repelCooldown, REPEL_COOLDOWN_SECONDS)) {
            activateRepel(player);
            repelCooldown.put(playerId, System.currentTimeMillis());
            playCooldownAnimation(player, REPEL_COOLDOWN_SECONDS);
        } else {
            showCooldownMessage(player, "Repel", repelCooldown.get(playerId), REPEL_COOLDOWN_SECONDS);
        }
    }

    private void handleAttract(Player player) {
        UUID playerId = player.getUniqueId();
        if (isCooldownOver(playerId, attractCooldown, ATTRACT_COOLDOWN_SECONDS)) {
            activateAttract(player);
            attractCooldown.put(playerId, System.currentTimeMillis());
            playCooldownAnimation(player, ATTRACT_COOLDOWN_SECONDS);
        } else {
            showCooldownMessage(player, "Attract", attractCooldown.get(playerId), ATTRACT_COOLDOWN_SECONDS);
        }
    }

    private void handleBlockAttract(Player player, Block block) {
        if (block == null) return;

        UUID playerId = player.getUniqueId();
        if (isCooldownOver(playerId, blockAttractCooldown, BLOCK_ATTRACT_COOLDOWN_SECONDS)) {
            activateBlockAttract(player, block);
            blockAttractCooldown.put(playerId, System.currentTimeMillis());
            playCooldownAnimation(player, BLOCK_ATTRACT_COOLDOWN_SECONDS);
        } else {
            showCooldownMessage(player, "Block Attract", blockAttractCooldown.get(playerId), BLOCK_ATTRACT_COOLDOWN_SECONDS);
        }
    }

    private void activateRepel(Player caster) {
        Location casterLoc = caster.getLocation();
        World world = caster.getWorld();

        world.playSound(casterLoc, Sound.BLOCK_BEACON_DEACTIVATE, 1.0f, 2.0f);

        new BukkitRunnable() {
            int ticks = 0;
            @Override
            public void run() {
                if (ticks >= 100) { // 5 seconds
                    this.cancel();
                    return;
                }

                // Repel nearby entities
                for (Entity entity : caster.getNearbyEntities(EFFECT_RADIUS, EFFECT_RADIUS, EFFECT_RADIUS)) {
                    if ((entity instanceof Player || entity instanceof Mob) && entity != caster) {
                        Location entityLoc = entity.getLocation();
                        Vector direction = entityLoc.subtract(casterLoc).toVector().normalize();
                        entity.setVelocity(direction.multiply(REPEL_STRENGTH));
                    }
                }

                world.spawnParticle(Particle.SMOKE,
                        casterLoc,
                        10, 1, 1, 1, 0);
                world.spawnParticle(Particle.FLAME,
                        casterLoc,
                        5, 1, 1, 1, 0);

                ticks += 1;
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    private void activateAttract(Player caster) {
        Location casterLoc = caster.getLocation();
        World world = caster.getWorld();

        world.playSound(casterLoc, Sound.BLOCK_BEACON_ACTIVATE, 1.0f, 2.0f);

        new BukkitRunnable() {
            int ticks = 0;
            @Override
            public void run() {
                if (ticks >= 100) { // 10 seconds
                    this.cancel();
                    return;
                }

                // Attract nearby entities
                for (Entity entity : caster.getNearbyEntities(EFFECT_RADIUS, EFFECT_RADIUS, EFFECT_RADIUS)) {
                    if ((entity instanceof Player || entity instanceof Mob) && entity != caster) {
                        Location entityLoc = entity.getLocation();
                        Vector direction = caster.getLocation().subtract(entityLoc).toVector().normalize();
                        entity.setVelocity(direction.multiply(ATTRACT_STRENGTH));
                    }
                }

                world.spawnParticle(Particle.CRIMSON_SPORE,
                        casterLoc,
                        10, 1, 1, 1, 0);
                world.spawnParticle(Particle.PORTAL,
                        casterLoc,
                        5, 1, 1, 1, 0);

                ticks += 1;
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    private void activateBlockAttract(Player caster, Block block) {
        Location blockLoc = block.getLocation();
        World world = block.getWorld();

        // Cancel existing task for this location if it exists
        if (attractiveBlockTasks.containsKey(blockLoc)) {
            attractiveBlockTasks.get(blockLoc).cancel();
            attractiveBlockTasks.remove(blockLoc);
            attractiveBlocks.remove(blockLoc);
        }

        attractiveBlocks.add(blockLoc);
        world.playSound(blockLoc, Sound.BLOCK_ENCHANTMENT_TABLE_USE, 1.0f, 1.0f);

        // Create new attraction task
        BukkitRunnable attractTask = new BukkitRunnable() {
            @Override
            public void run() {
                for (Entity entity : blockLoc.getWorld().getNearbyEntities(blockLoc, EFFECT_RADIUS, EFFECT_RADIUS, EFFECT_RADIUS)) {
                    if ((entity instanceof Player || entity instanceof Mob) && entity != caster) {
                        Vector direction = blockLoc.clone().add(0.5, 0.5, 0.5)
                                .subtract(entity.getLocation()).toVector().normalize();
                        entity.setVelocity(direction.multiply(BLOCK_ATTRACT_STRENGTH));
                    }
                }
            }
        };
        attractTask.runTaskTimer(plugin, 0L, 1L);
        attractiveBlockTasks.put(blockLoc, attractTask);

        // Schedule removal
        new BukkitRunnable() {
            @Override
            public void run() {
                attractiveBlocks.remove(blockLoc);
                BukkitRunnable task = attractiveBlockTasks.remove(blockLoc);
                if (task != null) {
                    task.cancel();
                }
                world.playSound(blockLoc, Sound.BLOCK_ENCHANTMENT_TABLE_USE, 1.0f, 0.5f);
            }
        }.runTaskLater(plugin, 150); // 30 seconds
    }

    private void showCooldownMessage(Player player, String abilityName, long lastUsed, int cooldownSeconds) {
        long timeLeft = cooldownSeconds - (System.currentTimeMillis() - lastUsed) / 1000;
        player.sendMessage(ChatColor.RED + "⏳ " + abilityName + " cooling down: " + timeLeft + "s remaining");
    }

    private void playCooldownAnimation(Player player, int duration) {
        new BukkitRunnable() {
            final Location loc = player.getLocation();
            double t = 0;

            @Override
            public void run() {
                t += 0.1;
                if (t > duration) {
                    this.cancel();
                    return;
                }

                double x = Math.cos(t * 2) * 0.5;
                double z = Math.sin(t * 2) * 0.5;
                loc.add(x, 0, z);
                player.spawnParticle(Particle.PORTAL, loc, 1, 0, 0, 0, 0);
                loc.subtract(x, 0, z);
            }
        }.runTaskTimer(plugin, 0L, 2L);
    }

    private boolean isCooldownOver(UUID playerId, HashMap<UUID, Long> cooldownMap, int cooldownSeconds) {
        return !cooldownMap.containsKey(playerId) ||
                (System.currentTimeMillis() - cooldownMap.get(playerId)) / 1000 >= cooldownSeconds;
    }
}