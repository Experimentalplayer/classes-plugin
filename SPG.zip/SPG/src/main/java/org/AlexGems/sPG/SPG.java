package org.AlexGems.sPG;

import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.TabCompleter;
import org.bukkit.ChatColor;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class SPG extends JavaPlugin implements CommandExecutor, TabCompleter {
    private List<String> classes;
    private Random random;

    // Class instances
    public ShadeWalker shadeWalker;
    public DreamWeaver dreamWeaver;
    public ArenaChampion arenaChampion;
    public DiminutiveEnchanter diminutiveEnchanter;
    public Polarity polarity; // Add this line

    @Override
    public void onEnable() {
        random = new Random();
        classes = new ArrayList<>();

        classes.add("ShadeWalker");
        classes.add("Dreamwalker");
        classes.add("ArenaChampion");
        classes.add("DiminutiveEnchanter");
        classes.add("Polarity");

        // Instantiate classes
        shadeWalker = new ShadeWalker(this);
        dreamWeaver = new DreamWeaver(this);
        arenaChampion = new ArenaChampion(this);
        diminutiveEnchanter = new DiminutiveEnchanter(this);
        polarity = new Polarity(this); // Initialize Polarity

        // Register commands
        this.getCommand("randomclass").setExecutor(this);
        this.getCommand("selectclass").setExecutor(this);
        this.getCommand("selectclass").setTabCompleter(this);

        // Register event listeners
        getServer().getPluginManager().registerEvents(shadeWalker, this);
        getServer().getPluginManager().registerEvents(dreamWeaver, this);
        getServer().getPluginManager().registerEvents(arenaChampion, this);
        getServer().getPluginManager().registerEvents(diminutiveEnchanter, this);
        getServer().getPluginManager().registerEvents(polarity, this); // Register Polarity

        getLogger().info("SPG plugin enabled!");
    }

    @Override
    public void onDisable() {
        getLogger().info("SPG plugin disabled!");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("This command can only be used by players!");
            return true;
        }

        Player player = (Player) sender;

        if (command.getName().equalsIgnoreCase("randomclass")) {
            resetPlayerClass(player);
            String randomClass = pickRandomClass();
            setPlayerClass(player, randomClass);
            return true;
        } else if (command.getName().equalsIgnoreCase("selectclass")) {
            if (args.length == 0) {
                player.sendMessage(ChatColor.RED + "Usage: /selectclass <class>");
                return true;
            }

            String selectedClass = args[0];
            if (classes.contains(selectedClass)) {
                resetPlayerClass(player);
                setPlayerClass(player, selectedClass);
            } else {
                player.sendMessage(ChatColor.RED + "Invalid class! Available classes: " + String.join(", ", classes));
            }
            return true;
        }

        return false;
    }

    private void resetPlayerClass(Player player) {
        shadeWalker.getHasClassMap().remove(player.getUniqueId());
        dreamWeaver.getHasClassMap().remove(player.getUniqueId());
        arenaChampion.getHasClassMap().remove(player.getUniqueId());
        diminutiveEnchanter.getHasClassMap().remove(player.getUniqueId());
        polarity.getHasClassMap().remove(player.getUniqueId()); // Reset Polarity class
    }

    private void setPlayerClass(Player player, String className) {
        switch (className) {
            case "Shade Walker":
                shadeWalker.getHasClassMap().put(player.getUniqueId(), true);
                player.sendMessage(ChatColor.DARK_GRAY + "You are now a ShadeWalker! Master the shadows!");
                player.sendMessage(ChatColor.GRAY + "Abilities:");
                player.sendMessage(ChatColor.GRAY + "- Right Click: Cast Darkness");
                player.sendMessage(ChatColor.GRAY + "- Shift + Left Click: Disable Movement");
                player.sendMessage(ChatColor.GRAY + "- Shift + Right Click: Turn into shadows and teleport behind the nearest mob");
                break;

            case "Dream Weaver":
                dreamWeaver.getHasClassMap().put(player.getUniqueId(), true);
                player.sendMessage(ChatColor.LIGHT_PURPLE + "You are now a Dreamwalker! Navigate the realm of dreams!");
                player.sendMessage(ChatColor.GRAY + "Abilities:");
                player.sendMessage(ChatColor.GRAY + "- Shift + Right Click: Enter Dream State (temporary invulnerability)");
                player.sendMessage(ChatColor.GRAY + "- Shift + Left Click: Nightmare Visage (scare enemies, causing fear)");
                player.sendMessage(ChatColor.GRAY + "- Right Click: Dreamweave (create illusions to confuse foes)");
                break;

            case "Arena Champion":
                arenaChampion.getHasClassMap().put(player.getUniqueId(), true);
                player.sendMessage(ChatColor.GOLD + "You are now an Arena Champion! Use your arena abilities wisely!");
                player.sendMessage(ChatColor.GRAY + "Abilities:");
                player.sendMessage(ChatColor.GRAY + "- Right Click: Create an Arena Trap");
                player.sendMessage(ChatColor.GRAY + "- Shift + Left Click: Empower Your Attacks");
                player.sendMessage(ChatColor.GRAY + "- Shift + Right Click: Rejuvenate Your Health");
                break;

            case "Diminutive Enchanter":
                diminutiveEnchanter.getHasClassMap().put(player.getUniqueId(), true);
                player.sendMessage(ChatColor.BLUE + "You are now a Diminutive Enchanter! Control sizes with your magic!");
                player.sendMessage(ChatColor.GRAY + "Abilities:");
                player.sendMessage(ChatColor.GRAY + "- Right Click: Enlarge your enemies");
                player.sendMessage(ChatColor.GRAY + "- Shift + Left Click: Shrink yourself");
                player.sendMessage(ChatColor.GRAY + "- Shift + Right Click: Enlarge yourself");
                break;


             case "Polarity":
                 polarity.getHasClassMap().put(player.getUniqueId(), true);
                 player.sendMessage(ChatColor.AQUA + "You are now a Polarity user! Control the forces around you!");
                 player.sendMessage(ChatColor.GRAY + "Abilities:");
                 player.sendMessage(ChatColor.GRAY + "- Shift + Left Click: Repel enemies");
                 player.sendMessage(ChatColor.GRAY + "- Shift + Right Click: Attract enemies");
                 player.sendMessage(ChatColor.GRAY + "- Right Click: Attract blocks");
                 break;
        }
    }

    private String pickRandomClass() {
        int index = random.nextInt(classes.size());
        return classes.get(index);
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String label, String[] args) {
        if (command.getName().equalsIgnoreCase("selectclass")) {
            if (args.length == 1) {
                List<String> suggestions = new ArrayList<>();
                for (String className : classes) {
                    if (className.toLowerCase().startsWith(args[0].toLowerCase())) {
                        suggestions.add(className);
                    }
                }
                return suggestions;
            }
        }
        return null;
    }
}
