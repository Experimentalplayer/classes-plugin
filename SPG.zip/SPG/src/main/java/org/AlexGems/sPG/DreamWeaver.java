package org.AlexGems.sPG;

import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.Listener;
import org.bukkit.event.EventHandler;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.ChatColor;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.UUID;
import java.util.Random;

public class DreamWeaver implements Listener {
    private final HashMap<UUID, Long> somnolentBurstCooldown = new HashMap<>();
    private final HashMap<UUID, Long> dreamMirageCooldown = new HashMap<>();
    private final HashMap<UUID, Long> dreamWalkCooldown = new HashMap<>();
    private final HashMap<UUID, Boolean> hasClass = new HashMap<>();
    private final SPG plugin;
    private final Random random = new Random();

    private static final int SOMNOLENT_BURST_COOLDOWN_SECONDS = 60;
    private static final int DREAM_MIRAGE_COOLDOWN_SECONDS = 90;
    private static final int DREAM_WALK_COOLDOWN_SECONDS = 90;

    public DreamWeaver(SPG plugin) {
        this.plugin = plugin;
    }

    public HashMap<UUID, Boolean> getHasClassMap() {
        return hasClass;
    }

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        UUID playerId = player.getUniqueId();
        Action action = event.getAction();

        if (!hasClass.getOrDefault(playerId, false)) {
            return;
        }

        // Check if the player is holding nothing
        boolean isHoldingNothing = player.getInventory().getItemInMainHand().getType() == Material.AIR;

        if (!player.isSneaking()) {
            // Require holding nothing for the right-click action
            if ((action == Action.RIGHT_CLICK_AIR || action == Action.RIGHT_CLICK_BLOCK) && isHoldingNothing) {
                if (isCooldownOver(playerId, dreamWalkCooldown, DREAM_WALK_COOLDOWN_SECONDS)) {
                    dreamWalk(player);
                    dreamWalkCooldown.put(playerId, System.currentTimeMillis());
                    player.sendMessage(ChatColor.LIGHT_PURPLE + "You have dreamwalked to a new location!");
                } else {
                    player.sendMessage(ChatColor.RED + "Dream Walk ability is on cooldown!");
                }
                return;
            }
        } else {
            if (action == Action.LEFT_CLICK_AIR || action == Action.LEFT_CLICK_BLOCK) {
                if (isCooldownOver(playerId, somnolentBurstCooldown, SOMNOLENT_BURST_COOLDOWN_SECONDS)) {
                    somnolentBurst(player);
                    somnolentBurstCooldown.put(playerId, System.currentTimeMillis());
                    player.sendMessage(ChatColor.DARK_PURPLE + "You released a burst of dream energy!");
                } else {
                    player.sendMessage(ChatColor.RED + "Somnolent Burst ability is on cooldown!");
                }
                return;
            }

            if (action == Action.RIGHT_CLICK_AIR || action == Action.RIGHT_CLICK_BLOCK) {
                if (isCooldownOver(playerId, dreamMirageCooldown, DREAM_MIRAGE_COOLDOWN_SECONDS)) {
                    dreamMirage(player);
                    dreamMirageCooldown.put(playerId, System.currentTimeMillis());
                    player.sendMessage(ChatColor.AQUA + "You have created a dream mirage!");
                } else {
                    player.sendMessage(ChatColor.RED + "Dream Mirage ability is on cooldown!");
                }
            }
        }
    }

    private boolean isCooldownOver(UUID playerId, HashMap<UUID, Long> cooldownMap, int cooldownSeconds) {
        return !cooldownMap.containsKey(playerId) ||
                (System.currentTimeMillis() - cooldownMap.get(playerId)) / 1000 >= cooldownSeconds;
    }

    private void dreamWalk(Player player) {
        Location targetLocation = player.getTargetBlock(null, 30).getLocation().add(0, 1, 0);

        // Create particle trail effect
        createDreamTrail(player.getLocation(), targetLocation);

        player.teleport(targetLocation);
        player.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, 100, 1));
        player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 100, 1));

        // Create dream portal effect at both locations
        createDreamPortal(player.getLocation());
        createDreamPortal(targetLocation);

        for (Entity entity : player.getNearbyEntities(7, 7, 7)) {
            if (entity instanceof Player && entity != player) {
                Player nearbyPlayer = (Player) entity;
                nearbyPlayer.sendMessage(ChatColor.BLUE + "You feel drawn into a dream...");
                nearbyPlayer.addPotionEffect(new PotionEffect(PotionEffectType.NAUSEA, 100, 1));
                nearbyPlayer.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 60, 1));
                nearbyPlayer.setWalkSpeed(0);

                new BukkitRunnable() {
                    @Override
                    public void run() {
                        nearbyPlayer.setWalkSpeed(0.2f);
                    }
                }.runTaskLater(plugin, 60);
            }
        }
    }

    private void somnolentBurst(Player player) {
        Location playerLocation = player.getLocation();
        World world = player.getWorld();

        // Create expanding ring effect
        new BukkitRunnable() {
            double radius = 0;
            final double maxRadius = 10;

            @Override
            public void run() {
                if (radius >= maxRadius) {
                    this.cancel();
                    return;
                }

                for (double angle = 0; angle < Math.PI * 2; angle += Math.PI / 16) {
                    double x = Math.cos(angle) * radius;
                    double z = Math.sin(angle) * radius;
                    Location particleLoc = playerLocation.clone().add(x, 0.5, z);
                    world.spawnParticle(Particle.DRAGON_BREATH, particleLoc, 1, 0, 0, 0, 0);
                    world.spawnParticle(Particle.WITCH, particleLoc, 1, 0, 0, 0, 0);
                }

                radius += 0.5;
            }
        }.runTaskTimer(plugin, 0L, 1L);

        for (Entity entity : player.getNearbyEntities(10, 10, 10)) {
            if (entity instanceof LivingEntity && entity != player) {
                LivingEntity target = (LivingEntity) entity;

                // Calculate direction vector from player to target
                Vector direction = target.getLocation().toVector()
                        .subtract(playerLocation.toVector()).normalize();

                // Apply enhanced knockback and effects
                target.setVelocity(direction.multiply(2));
                target.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 100, 2));
                target.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, 100, 1));

                if (target instanceof Player) {
                    ((Player) target).sendMessage(ChatColor.RED + "Dream energy courses through you!");
                }
            }
        }

        // Create central burst effect
        world.spawnParticle(Particle.EXPLOSION, playerLocation, 1);
        world.spawnParticle(Particle.END_ROD, playerLocation, 50, 0.5, 0.5, 0.5, 0.2);
        world.playSound(playerLocation, Sound.ENTITY_DRAGON_FIREBALL_EXPLODE, 1.0f, 1.0f);
    }

    private void dreamMirage(Player player) {
        Location playerLocation = player.getLocation();
        World world = player.getWorld();

        // Create multiple mirages
        for (int i = 0; i < 3; i++) {
            double angle = (2 * Math.PI * i) / 3;
            double x = Math.cos(angle) * 3;
            double z = Math.sin(angle) * 3;
            Location mirageLoc = playerLocation.clone().add(x, 0, z);

            ArmorStand mirage = world.spawn(mirageLoc, ArmorStand.class);
            mirage.setVisible(false);
            mirage.setGravity(false);
            mirage.setCustomName(ChatColor.LIGHT_PURPLE + "✧ Mirage of " + player.getName() + " ✧");
            mirage.setCustomNameVisible(true);

            // Create swirling particle effect around each mirage
            new BukkitRunnable() {
                double angle = 0;
                int tick = 0;

                @Override
                public void run() {
                    if (tick >= 200 || !mirage.isValid()) {
                        mirage.remove();
                        this.cancel();
                        return;
                    }

                    double x = Math.cos(angle) * 1.5;
                    double z = Math.sin(angle) * 1.5;
                    Location particleLoc = mirage.getLocation().add(x, 1, z);

                    world.spawnParticle(Particle.WITCH, particleLoc, 1, 0, 0, 0, 0);
                    world.spawnParticle(Particle.END_ROD, particleLoc, 1, 0, 0, 0, 0);

                    angle += Math.PI / 8;
                    tick++;
                }
            }.runTaskTimer(plugin, 0L, 1L);
        }

        // Add confusion effect to nearby players
        for (Entity entity : player.getNearbyEntities(10, 10, 10)) {
            if (entity instanceof Player && entity != player) {
                Player nearbyPlayer = (Player) entity;
                nearbyPlayer.addPotionEffect(new PotionEffect(PotionEffectType.NAUSEA, 200, 0));
                nearbyPlayer.sendMessage(ChatColor.LIGHT_PURPLE + "Multiple mirages dance before your eyes!");
            }
        }
    }

    private void createDreamTrail(Location start, Location end) {
        Vector direction = end.toVector().subtract(start.toVector());
        double distance = direction.length();
        direction.normalize();

        new BukkitRunnable() {
            double progress = 0;

            @Override
            public void run() {
                if (progress >= distance) {
                    this.cancel();
                    return;
                }

                Location current = start.clone().add(direction.clone().multiply(progress));
                current.getWorld().spawnParticle(Particle.END_ROD, current, 5, 0.1, 0.1, 0.1, 0.02);
                current.getWorld().spawnParticle(Particle.WITCH, current, 2, 0.1, 0.1, 0.1, 0);

                progress += 0.5;
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    private void createDreamPortal(Location location) {
        World world = location.getWorld();

        new BukkitRunnable() {
            double angle = 0;
            int tick = 0;

            @Override
            public void run() {
                if (tick >= 20) {
                    this.cancel();
                    return;
                }

                for (double i = 0; i < Math.PI * 2; i += Math.PI / 8) {
                    double x = Math.cos(i + angle) * 1.5;
                    double z = Math.sin(i + angle) * 1.5;
                    Location particleLoc = location.clone().add(x, tick * 0.1, z);

                    world.spawnParticle(Particle.PORTAL, particleLoc, 1, 0, 0, 0, 0);
                    world.spawnParticle(Particle.END_ROD, particleLoc, 1, 0, 0, 0, 0);
                }

                angle += Math.PI / 16;
                tick++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }
}